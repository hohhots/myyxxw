<?php
 
                /***************************************************************************
		                                adminmain.php(CHINA)
		                             -------------------
		    begin                : March Sat 8 2003
		    copyright            : (C) 2003 The nm114.net Group
		    email                : brgd@263.net
		
		    $Id: index.php,v 0.1 2003/03/08 brgd $
		
		 ***************************************************************************/
		
 if ( !defined('IN_MYY') )
 {
	 die("�Բ�����Ч���ʡ�<p>Sorry! This accessing is not valid! Try again.");
 }
  //���峣��
 
 $myylang['modify'] = '[ �޸� ]';
 $myylang['delete'] = '[ ɾ�� ]';
 $myylang['postarticle'] = '[ ���� ]';
 $myylang['newcat'] = '[ ��Ŀ¼ ]';
 $myylang['modifyuser']  = '[ ' . '�޸��û�' . ' ]';
 $myylang['posttitle']   = '���⣺';
 $myylang['postart']     = '���ݣ�';
 $myylang['pmvalue']     = '  �ύ  ';
 $myylang['username']    = '�û���:';
 $myylang['resume']      = '�û����:';
 $myylang['myyphotos']   = 'ͼ Ƭ';
 $myylang['firstdir']   = '[ ���� ]';
 $myylang['parentsdir']   = '[ ���� ]';
 $myylang['return']   = '[ ���� ]';
?>