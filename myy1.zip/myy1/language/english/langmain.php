<?php
 
                /***************************************************************************
		                                langmain.php(ENGLISH)
		                             -------------------
		    begin                : March Sat 8 2003
		    copyright            : (C) 2003 The nm114.net Group
		    email                : brgd@263.net
		
		    $Id: index.php,v 0.1 2003/03/08 brgd $
		
		 ***************************************************************************/
		
 if ( !defined('IN_MYY') )
 {
	 die("�Բ�����Ч���ʡ�<p>Sorry! This accessing is not valid! Try again.");
 }
  //���峣��
 $myylang['cat_table'] = 'myye_cat';
 $myylang['text_table'] = 'myye_text';
 $myylang['urls_table'] = 'myye_urls';
 $myylang['user_table'] = 'myy_user';
 $myylang['session_table'] = 'myy_sessions';
 
 $myylang['language'] = 'CHINESE';
 $myylang['encode'] = 'iso-8859-1';
 $myylang['title'] = 'Mongol medicine information web site - INNER MONGOLIA CHINA';
 $myylang['position'] = 'Your position';
 $myylang['search'] = 'go';
 $myylang['searchall'] = 'all catagory';
 $myylang['postdate'] = 'post time:';
 $myylang['writer'] = 'writer:';
 $myylang['urls'] = 'mongol medicine webs';
 $myylang['companyname'] = '���ɹŲ������念��ҽҩ�����о���������';
 $myylang['service'] = '<a href="http://www.nm114.cn"  target="_blank">���ɹų���������</a>&nbsp;&nbsp;�ṩ���缼��֧��&nbsp;&nbsp;2003��';
 $myylang['loginuserid'] = 'user  id:';
 $myylang['loginuserpass'] = 'password:';
 $myylang['login'] = ' login ';
 $myylang['searchkey'] = ':search have ';
 $myylang['searchresult'] = ' results.';
 $myylang['pagenum'] = 'all pages ';
 $myylang['resultsnum1'] = 'page ';
 $myylang['resultsnum2'] = '';
 $myylang['jump'] = 'jump';
 $myylang['forum'] = 'forum';
 $myylang['imgalt']= 'Click to view in large!';
 $myylang['defaulttitle'] = 'untitled';
?>