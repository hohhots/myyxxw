<?php
 
                /***************************************************************************
		                                adminmain.php(ENGLISH)
		                             -------------------
		    begin                : March Sat 8 2003
		    copyright            : (C) 2003 The nm114.net Group
		    email                : brgd@263.net
		
		    $Id: index.php,v 0.1 2003/03/08 brgd $
		
		 ***************************************************************************/
		
 if ( !defined('IN_MYY') )
 {
	 die("�Բ�����Ч���ʡ�<p>Sorry! This accessing is not valid! Try again.");
 }
  //���峣��
 
 $myylang['modify'] = '[ modify ]';
 $myylang['delete'] = '[ delete ]';
 $myylang['postarticle'] = '[ post ]';
 $myylang['newcat'] = '[ new dir ]';
 $myylang['modifyuser']  = '[ ' . 'modify user' . ' ]';
 $myylang['posttitle']   = 'Title:';
 $myylang['postart']     = 'Content:';
 $myylang['pmvalue']     = ' Submit ';
 $myylang['username']    = 'User Name:';
 $myylang['resume']      = 'User Resume:';
 $myylang['myyphotos']   = 'Web Album';
 $myylang['firstdir']   = '[ Top ]';
 $myylang['parentsdir']   = '[ Up ]';
 $myylang['return']   = '[ return ]';
?>