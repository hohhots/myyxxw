<?php
 
                /***************************************************************************
		                                constants.php
		                             -------------------
		    begin                : February Mon 4 2003
		    copyright            : (C) 2003 The nm114.net Group
		    email                : brgd@263.net
		
		    $Id: index.php,v 0.1 2003/04/13 brgd $
		
		 ***************************************************************************/

$myycookie['name'] = 'myynm114';
$myycookie['path'] = '';
$myycookie['domain'] = '';
$myycookie['secure'] = '0';
$myycookie['length'] = '600';
$myyURL = "http://192.168.0.25/myy1/";

$user = 'brgd';
$password = 'brgd';
$server = 'localhost';
$dbname = 'myy';

?>